<?php

declare(strict_types=1);

namespace Ryuu;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener {

    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->saveDefaultConfig();
    }

    public function onPlayerDeath(PlayerDeathEvent $event): void {
        $player = $event->getPlayer();
        $cause = $player->getLastDamageCause();

        if ($cause !== null) {
            $coordinates = $player->getPosition();
            $x = (int) $coordinates->getX();
            $y = (int) $coordinates->getY();
            $z = (int) $coordinates->getZ();

            $deathFormat = $this->getConfig()->getNested("death-message.format");
            $coordinatesFormat = $this->getConfig()->getNested("death-message.coordinates-format");

            $deathMessage = str_replace("{coordinates}", str_replace(["{x}", "{y}", "{z}"], [$x, $y, $z], $coordinatesFormat), $deathFormat);

            $player->sendMessage($deathMessage);
        }
    }
}
